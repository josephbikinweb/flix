<?php  
    $conn = mysqli_connect("localhost","root","","videoplayer");

     function query($query) {
        global $conn;
        $result = mysqli_query($conn, $query);
        $rows = [];
        while($row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
            // $rows sebagai array baru yang isinya row + row + row
        }
        return $rows;
    }
    
    function tambah($data) {
        global $conn;
    // ambil data dari tiap elemen dalam form 
    // supaya tidak mudah disusupi script dari orang luar alias dihack maka ditambahkan code : htmlspecialchars()
        $folder = htmlspecialchars($data ["folder"]);
        $nama_file = htmlspecialchars($data ["nama_file"]);
        $extension_id = htmlspecialchars($data ["extension_id"]);
        $categories_id = htmlspecialchars($data ["categories_id"]);
        $type_id = htmlspecialchars($data ["type_id"]);
        $nama_gambar = htmlspecialchars($data ["nama_gambar"]);
        
        $query = "INSERT INTO video 
                VALUES
        -- urutannya (id -meskipun nilai kosong krn autoincrement- JANGAN SAMPAI SALAH URUTAN )
                ('', 
                '$folder', 
                '$nama_file',
                '$extension_id',
                '$categories_id',
                '$type_id',
                '$nama_gambar'
                )
            ";
    // query insert data (koneksi, query) ; untuk menampilkan pakai SELECT * FROM
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }

    // HAPUS

     function hapus ($id) {
        global $conn;
        mysqli_query ($conn,"DELETE FROM video WHERE id = $id");
        
        return mysqli_affected_rows($conn);
    }

    // UBAH
     
    function ubah ($data) {
        global $conn;
    // ambil data dari tiap elemen dalam form 
    // supaya tidak mudah disusupi script dari orang luar alias dihack maka ditambahkan code : htmlspecialchars()
        $id = $data["id"];
        $folder = htmlspecialchars($data ["folder"]);
        $nama_file = htmlspecialchars($data ["nama_file"]);
        $extension_id = htmlspecialchars($data ["extension_id"]);
        $categories_id = htmlspecialchars($data ["categories_id"]);
        $type_id = htmlspecialchars($data ["type_id"]);
        $nama_gambar = htmlspecialchars($data ["nama_gambar"]);
    
        $query = "UPDATE video SET
                folder = '$folder', 
                nama_file = '$nama_file',
                extension_id = '$extension_id',
                categories_id = '$categories_id',
                type_id = '$type_id',
                nama_gambar = '$nama_gambar'
            WHERE id = $id
            ";
    // query insert data (koneksi, query) ; untuk menampilkan pakai SELECT * FROM
        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    }

    // function cari
    function cari($keyword) {
        $query = "SELECT * FROM video
                    WHERE
                    nama_file LIKE '%$keyword%'                      
                    categories LIKE '%$keyword%'                      
                ";
        return query($query);
    }
    
?>
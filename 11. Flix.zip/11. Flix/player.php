<?php
require 'function.php';
// $video = query("SELECT * FROM video ORDER BY video");
// $play = query("SELECT * FROM video ORDER BY nama_file DESC")[0];
$id = $_GET["id"];

$videos = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id");

$playVideos = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id WHERE v.id = $id");

$play = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id WHERE v.id = $id")[0];

$categories = query('SELECT * FROM categories');

$types = query('SELECT * FROM type');

// tombol cari ditekan
if (isset($_POST["cari"])) {
    $video = cari($_POST["keyword"]);
}

?>
<!DOCTYPE html>
    <html lang="en" ><head><meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/main.css" /><link rel="stylesheet" href="/assets/css/tooltipster.bundle.min.css" />
    <title>Creatrix</title>
    
    <style>
      body {
        background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("images/harry potter 2.jpg");
        background-color: #fafafa;
        background-repeat: no-repeat;
        background-position: center center;
        background-size: cover;
      }
    </style>
</head>
<body>
  <!-- navbar -->
  <nav class="navbar transp navbar-expand-md navbar-dark">
    <button class="navbar-toggler navbar-toggler-right pointer" type="button" data-toggle="collapse" data-target="#navbarCollapse">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="hidden-sm-down">
      <span class="navbar-brand link" data-href="index.php">
        <span class="fa fa-video-camera fa-fw text-info"></i></span>Creatrix</span>
    </div>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <?php  foreach ( $types as $type) : ?>
        <li class="nav-item">
          <a class="nav-link" href="movies.php?id=<?=  $type['id'] ?>"><?=  $type['type'] ?></a>
        </li>
        <?php  endforeach ?>
        <li class="nav-item dropdown">
              <div class="dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dLabel" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Categories
                </a>
                <div class="dropdown-menu" aria-labelledby="dLabel">
                  <?php  foreach ( $categories as $category) : ?>
                    <a class="dropdown-item" href="categories.php?id=<?=  $category['id'] ?>">
                  <?=  $category['categories'] ?>
                  </a>
                  <?php  endforeach ?>
                </div>
              </div>
        </li>
      </ul>
    </div>
  </nav>
  
  <!-- <div class="p-2" id="content" tabindex="-1"></div> -->
  <div class="d-flex justify-content-center mt-4">
    <div class="d-flex section-watch flex-column mt-4">
    
      <div id="playerwrapper" class="player p-2 m-2 rounded section-watch-video">
        <div id="errorcontainer" class="hide"></div>
        <div id="playercontainer">
          <div id="player" class="embed-responsive embed-responsive-16by9">
            <video class="video" controls>
              <source src="movies/<?= $play["folder"]; ?>/<?= $play["nama_file"]; ?>.<?= $play["ext"]; ?>" type="video/mp4">
            </video>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="d-flex flex-column p-0 pb-3 m-2 rounded section-watch-recommendations">
        <div class="p-1 watch-header h5 pt-3 font-weight-normal text-center">You may also like these Movies:
        </div>
        <div class="d-flex p-0 row m-0 justify-content-around text-center">
          <?php  foreach ( $videos as $video ) :?>
          <div class="col-md-2 py-2">
            <div class="cflip m-0 link2">
              <div class="flip m-0">
                <div class="card cardthumb front m-0">
                  <img class="card-img-top" onerror="style.display='none';" width="150" height="214"  src="images/<?= $video['nama_gambar'] ?>.jpg" />
                    <div class="card-img-overlay p-1 pt-2">
                      
                    </div>
                    <div class="card-footer mt-auto text-center"><?= ucwords($video['nama_file']) ?></div>
                </div>
                <div class="card cardthumb back m-0">
                  <div class="backthumbbg">
                    <img class="card-img-top flpdimg" onerror="style.display='none';" width="150" height="214"  src="images/<?= $video['nama_gambar'] ?>.jpg" />
                  </div>
                  <div class="card-img-overlay p-0">
                    <div class="d-flex flex-column text-white">
                      <div class="p-0 card-text t12 sh1"></div>
                      <div class="p-0 card-text mt-auto mx-2 t10 genres sh1"></div>
                      <div class="pt-1 pb-1 card-text">
                      </div>
                      <div class="pb-3 mb-3 card-text">
                        <a class="btn btn-md btn-info t16" href="player.php?id=<?= $video['id'] ?>" role="button">
                          <span class="fa fa-play fa-fw"></span> 
                          Watch Now
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="card-footer mt-auto text-center curs_default">
                    <span title="Rated: 8.1 out of 10 with 557,570 votes."><?= ucwords($video['folder'])   ?>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php  endforeach ?>
        </div>
      </div>

    <div class="container my-5">
      <div class="row">
        <form action="" method="post" class="mx-2">
          <div class="form-inline">
            <input type="text" name="keyword" size="40" autofocus placeholder="masukkan keyword pencarian.." autocomplete="off"  class="form-control" id="keyword">
            <button type="submit" name="cari" class="btn btn-primary ml-2" id="tombol-cari">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            </button>
          </div>
        </form>
      </div>
    </div>
      
    <div class="container" id="container">
      <div class="row">
        <table class="table table-borderless">
          <thead class="thead-dark">
            <tr>
              <th scope="col">No.</th>
              <!--Aksi untuk tombol ubah  -->
              <th scope="col">Judul</th>
              <th scope="col">Categories</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <?php $i = 1; ?>
              <?php foreach ($videos as $video) : ?>

                  <th class="th-row"><?= $i; ?> </th>
                  <td>
                    <a class="th-row" href="player.php?id=<?= $video["id"]; ?>"><?= $video["nama_file"]; ?></a>
                  </td>
                  <td>
                    <a class="th-row" href="categories.php?id=<?= $video["categories_id"]; ?>"><?= $video["categories"]; ?></a>
                  </td>
              </tr>
              <?php $i++; ?>
              <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>

  

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
  <script src="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/script.js"></script>
  </body>
</html>

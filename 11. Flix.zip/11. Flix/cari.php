<?php 
// untuk tes jadi gambar loader bisa muncul agak lama
// sleep(parameter 1 detik)
// sleep(1);

// kalau usleep bisa sampai micro detik
usleep(50000);
    require 'function.php';

    // kita ambil url keyword yang dikirim dari file script.js
    $keyword = $_GET['keyword'];

    // function cari kita copykan ke sini
    $query = "SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id
                WHERE
            v.nama_file LIKE '%$keyword%' OR
            c.categories LIKE '%$keyword%'  
            ";
    $videos = query($query);

    // untuk tes apakah var video sudah berhasil datanya
    // var_dump($videos);

?>
    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">No.</th>
            <!--Aksi untuk tombol ubah  -->
            <th scope="col">Judul</th>
            <th scope="col">Categories</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <?php $i = 1; ?>
            <?php foreach ($videos as $video) : ?>

                <th class="th-row"><?= $i; ?> </th>
                <td>
                  <a class="th-row" href="player.php?id=<?= $video["id"]; ?>"><?= $video["nama_file"]; ?></a>
                </td>
                <td>
                  <a class="th-row" href="categories.php?id=<?= $video["id"]; ?>"><?= $video["categories"]; ?></a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach ?>
        </tbody>
      </table>